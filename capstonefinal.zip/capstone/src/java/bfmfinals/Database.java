/*Only one database needed*/
package bfmfinals;

import java.sql.*;

public class Database {
    
    private static String url ="jdbc:mysql://localhost:3306/befitmamas";
    private static String user ="root";
    private static String password = "admin";
    
    public Database() {
        
    }
    
    public static Connection getConnection() throws SQLException {
        Connection con = null;
        con = DriverManager.getConnection(url, user, password);
        
        return con;
    }
}
