package bfmfinals;

public class Profiles {
    int profileID;
    String bio;
    String profilePic;
    int startWeight;
    int goalWeight;
    int calories;
    
    public Profiles() { 
    }
    /*set getters*/
    public int getProfileID() {
        return profileID;
    }
    public String getBio() {
        return bio;
    }
    public String getProfilePic() {
        return profilePic;
    }
    public int getStartWeight() {
        return startWeight;
    }
    public int getGoalWeight() {
        return goalWeight;
    }
    public int getCalories() {
    return calories;
}
    /* create setters*/
    public void setProfileID(int profileID) {
        this.profileID = profileID;
    }
    public void setBio(String bio) {
        this.bio = bio;
    }
    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }
    public void setStartWeight(int startWeight) {
        this.startWeight = startWeight;
    }
    public void setGoalWeight(int goalWeight) {
        this.goalWeight = goalWeight;
    }
    public void setCalories(int calories) {
        this.calories = calories;
    }
}
