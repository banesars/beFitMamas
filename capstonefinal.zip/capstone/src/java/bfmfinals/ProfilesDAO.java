package bfmfinals;

import java.sql.*;
import java.util.*;

public interface ProfilesDAO {
    Profiles get(int profileID) throws SQLException;
    
    List<Profiles> getAll () throws SQLException;
    
    int save(Profiles user) throws SQLException;
    
    int insert(Profiles user) throws SQLException;
    
    int update(Profiles user) throws SQLException;
    
    int delete(Profiles user) throws SQLException;
    
}
