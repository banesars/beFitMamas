package bfmfinals;

import java.sql.*;
import java.util.*;

public class ProfilesDAOImpl implements ProfilesDAO {

    @Override
    public Profiles get(int profileID) throws SQLException {
               Connection con = Database.getConnection();
               Profiles user = null;
               
               String sql = "SELECT profileID, bio, profilePic, startWeight, goalWeight, calories FROM profiles WHERE profileID = ?";
               PreparedStatement ps = con.prepareStatement(sql);
               
               ps.setInt(1, profileID);
               
               ResultSet rs = ps.executeQuery();
               
               if(rs.next()) {
                   int newProfileID = rs.getInt("profileID");
                   String bio = rs.getString("bio");
                   String profilePic = rs.getString("profilePic");
                   int startWeight = rs.getInt("startWeight");
                   int goalWeight = rs.getInt("goalWeight");
                   int calories = rs.getInt("calories");
                   
                   user = new Profiles();
                   
                   user.setProfileID(newProfileID);
                   user.setBio(bio);
                   user.setProfilePic(profilePic);
                   user.setStartWeight(startWeight);
                   user.setGoalWeight(goalWeight);
                   user.setCalories(calories);
            
               }
               return user;
    }
    @Override
    public List<Profiles> getAll() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int save(Profiles user) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int insert(Profiles user) throws SQLException {
         Connection con = Database.getConnection();
         
         String sql = "INSERT INTO profiles (profileID, bio, profilePic, startWeight, goalWeight, calories) VALUES (?, ?, ?, ?, ?, ?)";
         
          PreparedStatement ps = con.prepareStatement(sql);
          
          ps.setInt(1, user.getProfileID());
          ps.setString(2, user.getBio());
          ps.setString(3, user.getProfilePic());
          ps.setInt(4, user.getStartWeight());
          ps.setInt(5, user.getGoalWeight());
          ps.setInt(6, user.getCalories());
          
         int result = ps.executeUpdate();
         
         return result;
    }

    @Override
    public int update(Profiles user) throws SQLException {
                 Connection con = Database.getConnection();
                 
                 String sql = "UPDATE Profiles set bio = ?, profilePic = ?, startWeight = ?, goalWeight = ?, calories = ? WHERE profileID = ?";
        
        PreparedStatement ps = con.prepareStatement(sql);    
        
        ps.setString(1, user.getBio());
        ps.setString(2, user.getProfilePic());
        ps.setInt(3, user.getStartWeight());
        ps.setInt(4, user.getGoalWeight());
        ps.setInt(5, user.getCalories());
        
        int result = ps.executeUpdate();
        
        return result; 
        
    }

    @Override
    public int delete(Profiles user) throws SQLException {
        Connection con = Database.getConnection();

        String sql ="DELETE FROM Profiles WHERE profileID =?";

PreparedStatement ps = con.prepareStatement(sql);

ps.setInt(1, user.getProfileID());

int result = ps.executeUpdate();

return result;
    }
}
