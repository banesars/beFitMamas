package bfmfinals;

public class Users { 
    String username;
     String password;
    String email;
    String joinDate;

public Users() {
}
/*set getters*/
public String getUsername() {
return username;
}
public String getPassword() {
return password;
}
public String getEmail() {
return email;
}
public String getJoinDate() {
return joinDate;
}
/*create setters */
public void setUsername(String username) {
this.username = username;
}
public void setPassword(String password) {
this.password= password;
}
public void setEmail(String email) {
this.email = email;
}
public void setJoinDate(String joinDate) {
this.joinDate = joinDate;
}
}