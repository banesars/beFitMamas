package bfmfinals;

import java.sql.*;
import java.util.*;

public interface UsersDAO {
    Users get(String username) throws SQLException;
    
    List<Users> getAll () throws SQLException;
    
    int save(Users user) throws SQLException;
    
    int insert(Users user) throws SQLException;
   
    int update(Users user) throws SQLException;
    
    int delete(Users user) throws SQLException;
}
