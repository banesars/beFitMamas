package bfmfinals;

import java.sql.*;
import java.util.*;

public class UsersDAOImpl implements UsersDAO {
    
 @Override
	public Users get(String username) throws SQLException {
		Connection con = Database.getConnection();
		Users user = null;
		
		String sql = "SELECT username, password, email, joinDate FROM user WHERE username = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setString(1, username);
		
		ResultSet rs = ps.executeQuery();
		
		if (rs.next())	{
			String newUsername = rs.getString("username");
			String password = rs.getString("password");
                                                              String email = rs.getString("email");
			String joinDate = rs.getString("join_date");
			
			user= new Users();
			
                       
                        user.setUsername(newUsername);
                        user.setPassword(password);
                        user.setEmail(email);
                        user.setJoinDate(joinDate);
		}
		
		return user;
	}

    @Override
    public List<Users> getAll() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int save(Users user) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int insert(Users user) throws SQLException {
        Connection con = Database.getConnection();
        
        String sql = "INSERT INTO Users (username, password, email, join_date) VALUES(?, ?, ?, ?)";
        
        PreparedStatement ps = con.prepareStatement(sql);
        
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getPassword());
        ps.setString(3, user.getEmail());
        ps.setString(4, user.getJoinDate());
        
        int result = ps.executeUpdate();
        
        return result;
      }

    @Override
    public int update(Users user) throws SQLException {
       Connection con = Database.getConnection();
        
        String sql = "UPDATE Users set password = ?, email = ?, joinDate = ? WHERE username = ?";
        
        PreparedStatement ps = con.prepareStatement(sql);
       
        ps.setString(1, user.getPassword());
        ps.setString(2, user.getEmail());
        ps.setString(3, user.getJoinDate());
        
        int result = ps.executeUpdate();
        
        return result;    
    }

    @Override
    public int delete(Users user) throws SQLException {
Connection con = Database.getConnection();

String sql ="DELETE FROM Users WHERE username =?";

PreparedStatement ps = con.prepareStatement(sql);

ps.setString(1, user.getUsername());

int result = ps.executeUpdate();

return result;

    }  
}